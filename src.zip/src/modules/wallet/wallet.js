(function () {
    'use strict';

    angular.module('app.wallet', [
        'app.wallet.assets',
        'app.wallet.portfolio',
        'app.wallet.transactions'
    ]);

})();
