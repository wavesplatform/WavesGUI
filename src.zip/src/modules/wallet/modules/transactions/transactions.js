(function () {
    'use strict';

    angular.module('app.wallet.transactions', []);
})();
