(function () {
    'use strict';

    const controller = function () {



    };

    angular.module('app.wallet').controller('WalletHeaderCtrl', controller);
})();
