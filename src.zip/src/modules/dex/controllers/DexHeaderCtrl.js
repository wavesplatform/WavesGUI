(function () {
    'use strict';

    angular.module('app.dex')
        .controller('DexHeaderCtrl', function () {

        });
})();
