(function () {
    'use strict';

    angular.module('app.ui').component('wLogo', {
        templateUrl: 'modules/ui/directives/logo/logo.html'
    });
})();
