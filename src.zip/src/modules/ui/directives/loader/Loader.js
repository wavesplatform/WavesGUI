(function () {
    'use strict';

    angular.module('app.ui').component('wLoader', {
        template: '<div class="loader"></div>'
    });
})();
