(function () {
    'use strict';

    angular.module('app.ui').component('wActions', {
        bindings: {},
        templateUrl: 'modules/ui/directives/actions/actions.html',
        transclude: true
    });
})();
